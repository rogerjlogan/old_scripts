
char tempgrpexpand[READLINELEN*20+1];


VectorMapSet[0]='\0';
fieldcount='A';
for(i=0;i<maxpin;i++) fieldset[i]=hexproc[i]='.';
fieldset[i]=hexproc[i]='\0';
wftpending=0;
ininherit=0;
newwavetable[0]='\0';
while(fgets(readstr,READLINELEN-1,fpin1) != NULL ){
   readstr[strlen(readstr)-1] = '\0';/* remove trailing \n */
   for (j=i=0;i<strlen(readstr);i++) {/* strip whitespace */
      if (isgraph((int)readstr[i])){tempgrpexpand2[j]=readstr[i];j++;}
      } /* end strip white space */
   if (NULL!=(ptr2=(strstr(tempgrpexpand2,"#begininheritlist")))) {/* don't forget we stripped whitespace!!!! */
      ininherit=1;
      fprintf(stderr,"Entering inherit table!\n");
      fileininhst=ftell(fpin1);
      }
   else if (NULL!=(ptr2=(strstr(tempgrpexpand2,"#endinheritlist")))) {/* don't forget we stripped whitespace!!!! */
      fprintf(stderr,"Exiting inherit table![%d]\n",i);
      ininherit=-1;
      }
   else if (ininherit==1) {
      ptr1=strchr(tempgrpexpand2,'[');
      ptr2=strchr(tempgrpexpand2,']');
      if (ptr1==NULL || ptr2==NULL) {
         continue;/* skip if not what we are looking for */
         }
      *ptr1='\0';
      strcpy(fullwftname,tempgrpexpand2);
//      fprintf(fpstatus,"wft[%s]\n",fullwftname);
      *ptr1='[';
      fprintf(fpwaves,"WaveformTable %s {\n",fullwftname);
      fprintf(fpwaves,"\tPeriod \"%s\";\n",tperiod);
      for (i=0,ptr=ptr1+1;ptr<ptr2;ptr++,i++) {
         if (*ptr=='X') {
            fprintf(fpwaves,"\tInherit WFT_%d;\n",i);
            }
         }
      fprintf(fpwaves,"\tCell \"ALLPINS\" d CPM_CALLING_DPM {Data 3 Other; Drive { EntryState DriveOn; } }\n");
      fprintf(fpwaves,"\tCell \"ALLPINS\" - HOLD_STATE {Data 6; Drive { EntryState DriveOn; } }\n");
      fprintf(fpwaves,"}\n");
      }
   else if (NULL!=(ptr2=(strstr(tempgrpexpand2,"VectorMapSetCycle")))) {
      /* throw this away */
      }

   else if (NULL!=(ptr2=(strstr(readstr,"VectorMapSet")))) {
      if (NULL!=(ptrSCAN=(strstr(readstr,"Scan")))) {
         if (strstr(readstr,"ScanInOrderVM")!=NULL || strstr(readstr,"ScanInVM")!=NULL ){
            ptr2=ptr3=NULL;
            ptr1=strchr(readstr,',');/* first comma */
            if (ptr1!=NULL) ptr2=strchr(ptr1+1,',');/* second */
            if (ptr2!=NULL) ptr3=strchr(ptr2+1,',');/* third comma */
            for (i=0,ptr=ptr2+1;ptr<ptr3;ptr++) if (*ptr!=' ') {PINNAME[i]=*ptr;i++;}
            PINNAME[i]='\0';
            plen=strlen(PINNAME);
            for (pin=0;pin<maxpin;pin++) {
               if (strstr(PIN[pin],PINNAME)==PIN[pin] && flag_group==0 ) break;/* check that the pinname matches(or is a substring of the pinfile pin */
               if (strstr(PIN[pin],PINNAME)==PIN[pin] && flag_group==1 &&(PIN[pin][plen]=='0' || PIN[pin][plen]=='1'|| PIN[pin][plen]=='2' || PIN[pin][plen]=='3'|| PIN[pin][plen]=='m')) break;/* check that the pinname matches(or is a substring of the pinfile pin */
               }
            fprintf(fpout1,"?SCANINPIN:%s %d\n",PINNAME,pin+1);
            }
         else if (strstr(readstr,"ScanOutOrderVM")!=NULL || strstr(readstr,"ScanOutVM")!=NULL ){
            ptr2=ptr3=NULL;
            ptr1=strchr(readstr,',');/* first comma */
            if (ptr1!=NULL) ptr2=strchr(ptr1+1,',');/* second */
            if (ptr2!=NULL) ptr3=strchr(ptr2+1,',');/* third comma */
            for (i=0,ptr=ptr2+1;ptr<ptr3;ptr++) if (*ptr!=' ') {PINNAME[i]=*ptr;i++;}
            PINNAME[i]='\0';
            plen=strlen(PINNAME);
            for (pin=0;pin<maxpin;pin++) {
               if (strstr(PIN[pin],PINNAME)==PIN[pin] && flag_group==0 ) break;/* check that the pinname matches(or is a substring of the pinfile pin */
               if (strstr(PIN[pin],PINNAME)==PIN[pin] && flag_group==1 &&(PIN[pin][plen]=='0' || PIN[pin][plen]=='1'|| PIN[pin][plen]=='2' || PIN[pin][plen]=='3'|| PIN[pin][plen]=='m')) break;/* check that the pinname matches(or is a substring of the pinfile pin */
               }
            fprintf(fpout1,"?SCANOUTPIN:%s %d\n",PINNAME,pin+1);
            }
         }
      else {
         if      (NULL!=strstr(tempgrpexpand2,"Hex"   )) hex_or_bin='H';
         else if (NULL!=strstr(tempgrpexpand2,"Binary")) hex_or_bin='B';
         ptr=strchr(tempgrpexpand2,',');
         ptr0=strchr(tempgrpexpand2,'(');
         if (ptr!=NULL) ptr2=strchr(ptr+1,','); else ptr2=NULL;
         if (ptr2!=NULL) ptr3=strchr(ptr2+1,','); else ptr3=NULL;
         if (ptr0!=NULL && ptr!=NULL) {
            *ptr='\0';
            if (strstr(ptr0+1,"Scan")!=NULL) ; /* shouldn't hit this now... if its a scan then skip it here */
            else if (VectorMapSet[0]=='\0') strcpy(VectorMapSet,ptr0+1);
            else if (0!=strcmp(VectorMapSet,ptr0+1)) {
               fprintf(stderr,"************\nMultiple VectorMapSets not supported in [%s]\n",infile1);
               fprintf(stderr,"Please request support or split the file!!!\n*************\n");
               fprintf(fperrors,"************\nMultiple VectorMapSets not supported in [%s]\n",infile1);
               fprintf(fperrors,"Please request support or split the file!!!\n*************\n");
               exit(7);
               }
            *ptr=',';
            }
         if (ptr2!=NULL && ptr3!=NULL) {
            *ptr3='\0';
            strcpy(tempgrpexpand,ptr2+1);
            *ptr3=',';
            }
         for (i=0;i<maxlists;i++) if (0==strcmp(tempgrpexpand,pinlist[i].pinlistname)){
            for (j=0;j<maxpin;j++) if (pinlist[i].pinlists[j]=='*') {
               hexproc[j]=hex_or_bin;
               fieldset[j]=fieldcount;
               }
            break;
            }
         if (i==maxlists) {/* not a group */
            for (j=0;j<maxpin;j++) {
               if (0==strcmp(tempgrpexpand,PIN[j])) {
                  hexproc[j]=hex_or_bin;
                  fieldset[j]=fieldcount;
                  break;
                  }
               }
            }
         fieldcount++;
         }
      }
   /* get subcomponent boundaries of line */
   else if (NULL!=(ptr2=(strstr(readstr,"CycleSetMD")))) {
      gctstart=(int)(strchr(readstr,'(')-&readstr[0])+1;
      gctend=(int)(strchr(readstr,',')-&readstr[0])-1;
      readstr[gctend+1]='~'; /* Disable for next comma search */
      ptr3=strchr(readstr,',');
      if (ptr3==NULL) continue;/* it might be in a comment.... */
      stwf2=(int)(ptr3-&readstr[0])+1;
      readstr[stwf2-1]='~';
      ptr3=strchr(readstr,',');
      if (ptr3==NULL) continue;/* it might still be in a comment.... */
      pinstart=(int)(ptr3-&readstr[0])+1;
      ptr3=strchr(readstr,')');
      if (ptr3==NULL) continue;/* it might still be in a comment.... */
      pinend=(int)(ptr3-&readstr[0])-1;
   
      if(DEBUG) fprintf(stdout,"<%s>\ngs%d ge%d ps%d pe%d\n",readstr,gctstart,gctend,pinstart,pinend);
   
      /* get subcomponents */
      for (j=0,i=gctstart;i<=gctend;i++) if(readstr[i]!=' ' && readstr[i]!='\t') GCTNAME[j++]=readstr[i];
      GCTNAME[j]='\0';
      if (DEBUG) fprintf(stdout,"GCTNAME=[%s]\n",GCTNAME);
   
      for (j=0,i=pinstart;i<=pinend;i++) if(readstr[i]!=' ' && readstr[i]!='\t') PINNAME[j++]=readstr[i];
      PINNAME[j]='\0';
      if (DEBUG) fprintf(stdout,"PINNAME=[%s]\n",PINNAME);


